import 'package:flutter/material.dart';
class dailyprice extends StatefulWidget {
  final List<String> dataList =[
    "  crops                 high              low ",
    "  wheat                0660             0300",
    "  Peanuts            1700             1100",
    "  Cotton               2200             1700",
    "  Millet                 0560             0300",
    "  Sorgum             0660             0300",
    "  Sesame white  0660             0300",
    "  sesame black  0660             0300",
    "  corn                   0660             0300",
    "  chikpeas           0660             0300",
    "  Tuvar                 0660             0300",
    "  then                   0660             0300",
    "  Coriander         0660             0300",
    "  Fennel              0660             0300",
    "  onion                0660             0300",
    "  Potatoes          0660             0300",




  ];
  //const dailyprice({super.key});

  @override
  State<dailyprice> createState() => _dailypriceState();
}

class _dailypriceState extends State<dailyprice> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Text("TODAY PRICE",style: TextStyle(fontSize: 25),),
            Text("  10/4/2023")
          ],
        ),
      ),
      body:ListView.builder(
        itemCount: widget.dataList.length,
        itemBuilder: (context,index){
          return ListTile(
              title: Text(widget.dataList[index],style: TextStyle(fontSize: 20),)
          );
        },
      ),

    );
  }
}
void main(){
  runApp(MaterialApp(
    home: dailyprice(),
  ));
}
