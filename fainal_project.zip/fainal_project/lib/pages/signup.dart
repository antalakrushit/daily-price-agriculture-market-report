import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
class signup extends StatefulWidget {
  const signup({super.key});

  @override
  State<signup> createState() => _signupState();
}

class _signupState extends State<signup> {
  bool passtoggle = true;
  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      child:Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("images/f.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        child:SingleChildScrollView(
          child: SafeArea(
            child: Column(
              children: <Widget>[
                SizedBox(height: 100),
                Text("SIGN UP",style: TextStyle(fontSize: 60),),
                SizedBox(height: 60),
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: TextField(
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text("Enter Username"),
                      prefixIcon: Icon(Icons.person),
                    ),
                  ),
                ),
                SizedBox(height: 30,),
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: TextField(
                    obscureText: passtoggle ? true : false,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text("New Password"),
                      prefixIcon: Icon(Icons.lock),
                      suffixIcon: InkWell(
                        onTap: (){
                          if (passtoggle==true) {passtoggle =false;}
                          else {passtoggle=true;}
                          setState(() {});
                        },
                        child: passtoggle
                            ?Icon(CupertinoIcons.eye_slash_fill)
                            :Icon(CupertinoIcons.eye_fill),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 30,),
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: TextField(
                    obscureText: passtoggle ? true : false,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text("confirm Password"),
                      prefixIcon: Icon(Icons.lock),
                      suffixIcon: InkWell(
                        onTap: (){
                          if (passtoggle==true) {passtoggle =false;}
                          else {passtoggle=true;}
                          setState(() {});
                        },
                        child: passtoggle
                            ?Icon(CupertinoIcons.eye_slash_fill)
                            :Icon(CupertinoIcons.eye_fill),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 40,),

                ElevatedButton(onPressed: (){
                  Navigator.pushNamed(context,"/login");
                },
                    child:Text("Sign Up")),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
