import 'package:flutter/material.dart';
class home extends StatefulWidget {
  const home({super.key});

  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("images/h.jpeg"),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.only(top: 70),
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  IconButton(onPressed: (){}, icon: Icon(Icons.menu_book,size: 40,)),
                  SizedBox(width: 30,),
                  Column(children: <Widget>[
                    Text("A.P.M.C JAMKANDORNA",style: TextStyle(fontSize: 20),),
                    Text("Shree Sardar Patel Marketing Yard - Jamkandorna",style: TextStyle(fontSize:12),),
                  ]
                  ),
                ],
              ),
              SizedBox(
                height: 100,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 40),
                child: Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        SizedBox(
                          width: 300,
                          height: 60,
                          child: Opacity(
                            opacity: 0.8, // Set the opacity for the entire FilledButton.icon
                            child: FilledButton.icon(
                              onPressed: () {
                                Navigator.pushNamed(context, "/dailyprice");
                              },
                              icon: Icon(Icons.currency_rupee_rounded, size: 30,color: Colors.white,),
                              label: Text("Daily price", style: TextStyle(fontSize: 20,color: Colors.white)),
                            ),
                          ),
                        ),


                      ],
                    ),
                    SizedBox(height: 70,),
                    Row(
                      children: <Widget>[
                        SizedBox(
                          width: 300,
                          height: 60,
                          child: Opacity(
                            opacity: 0.8, // Set the opacity for the entire FilledButton.icon
                            child: FilledButton.icon(
                              onPressed: () {
                                Navigator.pushNamed(context, "/menu");
                              },
                              icon: Icon(Icons.newspaper, size: 30,color: Colors.white,),
                              label: Text("Importants news", style: TextStyle(fontSize: 20,color: Colors.white)),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 70,),
                    Row(
                      children: <Widget>[
                        SizedBox(
                          width: 300,
                          height: 60,
                          child: Opacity(
                            opacity: 0.8, // Set the opacity for the entire FilledButton.icon
                            child: FilledButton.icon(
                              onPressed: () {
                                Navigator.pushNamed(context, "/menu");
                              },
                              icon: Icon(Icons.people_outline_sharp, size: 30,color: Colors.white,),
                              label: Text("comistion aggents", style: TextStyle(fontSize: 20,color: Colors.white)),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 70,),
                    Row(
                      children: <Widget>[
                        SizedBox(
                          width: 300,
                          height: 60,
                          child: Opacity(
                            opacity: 0.8, // Set the opacity for the entire FilledButton.icon
                            child: FilledButton.icon(
                              onPressed: () {
                                Navigator.pushNamed(context, "/");
                              },
                              icon: Icon(Icons.connect_without_contact, size: 30,color: Colors.white,),
                              label: Text("contact", style: TextStyle(fontSize: 20,color: Colors.white)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
