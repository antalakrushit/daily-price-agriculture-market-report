import 'package:flutter/material.dart';
class frount extends StatefulWidget {
  const frount({super.key});

  @override
  State<frount> createState() => _frountState();
}

class _frountState extends State<frount> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
