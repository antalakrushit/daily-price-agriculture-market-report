import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
class login extends StatefulWidget {
  const login({super.key});

  @override
  State<login> createState() => _loginState();
}

class _loginState extends State<login> {
  bool passtoggle = true;
  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      child: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("images/f.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        child: SingleChildScrollView(
          child: SafeArea(
            child: Column(
              children: <Widget>[
                SizedBox(height: 150),
                Text("LOGIN",style: TextStyle(fontSize: 60),),
                SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: TextField(
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text("Enter Username"),
                      prefixIcon: Icon(Icons.person),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: TextField(
                    obscureText: passtoggle ? true : false,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text("Password"),
                      prefixIcon: Icon(Icons.lock),
                      suffixIcon: InkWell(
                        onTap: (){
                          if (passtoggle==true) {passtoggle =false;}
                          else {passtoggle=true;}
                          setState(() {});
                        },
                        child: passtoggle
                            ?Icon(CupertinoIcons.eye_slash_fill)
                            :Icon(CupertinoIcons.eye_fill),
                      ),
                    ),
                  ),
                ),
                ElevatedButton(onPressed: (){
                  Navigator.pushNamed(context,"/home");
                },
                    child:Text("Log in")),
                SizedBox(height: 200,),
                Padding(
                  padding: const EdgeInsets.only(left: 10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Create new account",style: TextStyle(fontSize: 15,color: Colors.red),),
                      TextButton(onPressed: (){
                        Navigator.pushNamed(context,"/signup");
                      }, child:Text("Create account",style: TextStyle(fontSize: 20),) ),
                    ],
                  ),
                ),

              ],
            ),
          ),
        ),
      ),
    );
  }
}
