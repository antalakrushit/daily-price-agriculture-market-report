
import 'package:fainal_project/pages/dailyprice.dart';
import 'package:fainal_project/pages/frount.dart';
import 'package:fainal_project/pages/home.dart';
import 'package:fainal_project/pages/login.dart';
import 'package:fainal_project/pages/signup.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(MaterialApp(

    routes: {
      "/": (context)=> frount(),
      "/login" : (context) =>login(),
      "/signup": (context)=>signup(),
      "/home": (context)=>home(),
      "/dailyprice":(context)=>dailyprice(),
    },
  ));
}

